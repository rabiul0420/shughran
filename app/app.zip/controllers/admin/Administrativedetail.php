<?php defined('BASEPATH') or exit('No direct script access allowed');

class Administrativedetail extends MY_Controller
{

    function __construct()
    {
        parent::__construct();
        if (!$this->loggedIn) {
            $this->session->set_userdata('requested_page', $this->uri->uri_string());
            $this->sma->md('login');
        }
        $this->lang->admin_load('manpower', $this->Settings->user_language);
        $this->load->library('form_validation');
        $this->load->helper('report');
        $this->load->admin_model('organization_model');
        $this->digital_upload_path = 'files/';
        $this->upload_path = 'assets/uploads/';
        $this->thumbs_path = 'assets/uploads/thumbs/';
        $this->image_types = 'gif|jpg|jpeg|png|tif';
        $this->digital_file_types = 'zip|psd|ai|rar|pdf|doc|docx|xls|xlsx|ppt|pptx|gif|jpg|jpeg|png|tif|txt';
        $this->allowed_file_size = '1024';
        $this->popup_attributes = array('width' => '900', 'height' => '600', 'window_name' => 'sma_popup', 'menubar' => 'yes', 'scrollbars' => 'yes', 'status' => 'no', 'resizable' => 'yes', 'screenx' => '0', 'screeny' => '0');
    }












    function district($branch_id = NULL)
    {


       
        $this->sma->checkPermissions();
        if ($branch_id != NULL && !($this->Owner || $this->Admin) && ($this->session->userdata('branch_id') != $branch_id)) {
            $this->session->set_flashdata('warning', lang('access_denied'));
            admin_redirect('organization/' . $this->session->userdata('branch_id'));
        } else if ($branch_id == NULL && !($this->Owner || $this->Admin)) {
            admin_redirect('organization/' . $this->session->userdata('branch_id'));
        }

        $this->data['error'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('error');

        if ($this->Owner || $this->Admin || !$this->session->userdata('branch_id')) {
            $this->data['branches'] = $this->site->getAllBranches();
            $this->data['branch_id'] = $branch_id;
            $this->data['branch'] = $branch_id ? $this->site->getBranchByID($branch_id) : NULL;
        } else {
            $this->data['branches'] = NULL;
            $this->data['branch_id'] = $this->session->userdata('branch_id');
            $this->data['branch'] = $this->session->userdata('branch_id') ? $this->site->getBranchByID($this->session->userdata('branch_id')) : NULL;
        }









        if ($branch_id) {


            $this->data['district_info'] = $this->site->query("SELECT sma_district.name district_name , b.*  FROM `sma_district` LEFT JOIN  
		
		(SELECT 
                    
                    
                    org_thana,
                    org_ward,
                    org_unit,
                    branch_number,
                    supporter_organization,district,
                    v3_count_zone(district, 2, 2,1) upazilla, v3_count_zone(district, 1, 2,1) thana
                    FROM (

                    SELECT 
                    SUM(CASE WHEN `level` = 1 THEN 1 ELSE 0 END) org_thana,
                    SUM(CASE WHEN `level` = 2 THEN 1 ELSE 0 END) org_ward,
                    SUM(CASE WHEN `level` = 3 THEN 1 ELSE 0 END) org_unit,
                    SUM(supporter_organization) supporter_organization,
                    COUNT(DISTINCT(branch_id)) branch_number, 
                    district
                    FROM sma_thana where branch_id = $branch_id GROUP BY  district 
                        
                    ) a )b ON sma_district.id = b.district WHERE sma_district.level=1
                    AND  sma_district.id  IN (
SELECT DISTINCT district_id FROM   sma_administrative_area WHERE   branch_id = $branch_id                   
                    )
                    
                    ");



        } else {

            $this->data['district_info'] = $this->site->query("SELECT sma_district.name district_name , b.*  FROM `sma_district` LEFT JOIN  
		
		(SELECT 
                    
                    
                    org_thana,
                    org_ward,
                    org_unit,
                    branch_number,
                    supporter_organization,district,
                    v3_count_zone(district, 2, 2,1) upazilla, v3_count_zone(district, 1, 2,1) thana
                    FROM (

                    SELECT 
                    SUM(CASE WHEN `level` = 1 THEN 1 ELSE 0 END) org_thana,
                    SUM(CASE WHEN `level` = 2 THEN 1 ELSE 0 END) org_ward,
                    SUM(CASE WHEN `level` = 3 THEN 1 ELSE 0 END) org_unit,
                    SUM(supporter_organization) supporter_organization,
                    COUNT(DISTINCT(branch_id)) branch_number, 
                    district
                    FROM sma_thana GROUP BY  district 
                        
                    ) a )b ON sma_district.id = b.district WHERE sma_district.level=1");
        }







        /// $this->sma->print_arrays($this->data['org_summary']);
        $bc = array(array('link' => base_url(), 'page' => lang('home')), array('link' => '#', 'page' => 'Administrative detail'));
        $meta = array('page_title' => 'Administrative detail', 'bc' => $bc);
       
            $this->page_construct('administrativedetail/index', $meta, $this->data, 'leftmenu/organization');
    

}



function thana( $branch_id = NULL)
{


   
    $this->sma->checkPermissions();
    if ($branch_id != NULL && !($this->Owner || $this->Admin) && ($this->session->userdata('branch_id') != $branch_id)) {
        $this->session->set_flashdata('warning', lang('access_denied'));
        admin_redirect('organization/' . $this->session->userdata('branch_id'));
    } else if ($branch_id == NULL && !($this->Owner || $this->Admin)) {
        admin_redirect('organization/' . $this->session->userdata('branch_id'));
    }

    $this->data['error'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('error');

    if ($this->Owner || $this->Admin || !$this->session->userdata('branch_id')) {
        $this->data['branches'] = $this->site->getAllBranches();
        $this->data['branch_id'] = $branch_id;
        $this->data['branch'] = $branch_id ? $this->site->getBranchByID($branch_id) : NULL;
    } else {
        $this->data['branches'] = NULL;
        $this->data['branch_id'] = $this->session->userdata('branch_id');
        $this->data['branch'] = $this->session->userdata('branch_id') ? $this->site->getBranchByID($this->session->userdata('branch_id')) : NULL;
    }






    


    if ($branch_id) {


        $this->data['thana_info'] = $this->site->query("SELECT sma_district.name thana_name ,v3_district_upazila( sma_district.parent_top_level) district_name, b.*  FROM `sma_district` LEFT JOIN  
		
		(  SELECT          org_thana,
                    org_ward,
                    org_unit,
                    branch_number,
                    supporter_organization,district,upazila,
                      v3_count_zone(upazila, 1, 4,2) ward_number
                    FROM (
                    
                    SELECT 
                    SUM(CASE WHEN sma_thana.`level` = 1 THEN 1 ELSE 0 END) org_thana,
                    SUM(CASE WHEN sma_thana.`level` = 2 THEN 1 ELSE 0 END) org_ward,
                    SUM(CASE WHEN sma_thana.`level` = 3 THEN 1 ELSE 0 END) org_unit,
                    SUM(supporter_organization) supporter_organization,
                    COUNT(DISTINCT(branch_id)) branch_number, 
                    district, upazila 
                    FROM sma_thana 
                    LEFT JOIN sma_district ON sma_district.id = sma_thana.upazila 
                                       
                    
                    WHERE 
                     branch_id = $branch_id AND   sma_district.level = 2 AND   sma_district.zone_type =1             
                     GROUP BY  district,upazila 
                        
                    ) a 
                    
                                        
                    )b ON sma_district.id = b.upazila WHERE sma_district.level=2 AND sma_district.zone_type = 1 
                    AND   sma_district.id  IN (
SELECT DISTINCT thana_upazila_id FROM   sma_administrative_area WHERE   branch_id = $branch_id                   
                    )

                    ");



    } else {

        $this->data['district_info'] = $this->site->query("SELECT sma_district.name thana_name ,v3_district_upazila( sma_district.parent_top_level) district_name, b.*  FROM `sma_district` LEFT JOIN  
		
		(  SELECT          org_thana,
                    org_ward,
                    org_unit,
                    branch_number,
                    supporter_organization,district,upazila,
                      v3_count_zone(upazila, 1, 4,2) ward_number
                    FROM (
                    
                    SELECT 
                    SUM(CASE WHEN sma_thana.`level` = 1 THEN 1 ELSE 0 END) org_thana,
                    SUM(CASE WHEN sma_thana.`level` = 2 THEN 1 ELSE 0 END) org_ward,
                    SUM(CASE WHEN sma_thana.`level` = 3 THEN 1 ELSE 0 END) org_unit,
                    SUM(supporter_organization) supporter_organization,
                    COUNT(DISTINCT(branch_id)) branch_number, 
                    district, upazila 
                    FROM sma_thana 
                    LEFT JOIN sma_district ON sma_district.id = sma_thana.upazila 
                                       
                    
                    WHERE 
                        sma_district.level = 2 AND   sma_district.zone_type = 1              
                     GROUP BY  district,upazila 
                        
                    ) a 
                    
                                        
                    )b ON sma_district.id = b.upazila WHERE sma_district.level=2 AND sma_district.zone_type = 1");
    }




   


    /// $this->sma->print_arrays($this->data['org_summary']);
    $bc = array(array('link' => base_url(), 'page' => lang('home')), array('link' => '#', 'page' => 'Administrative detail'));
    $meta = array('page_title' => 'Administrative detail', 'bc' => $bc);
   
        $this->page_construct('administrativedetail/thana', $meta, $this->data, 'leftmenu/organization');


}









function upazila( $branch_id = NULL)
{


   
    $this->sma->checkPermissions();
    if ($branch_id != NULL && !($this->Owner || $this->Admin) && ($this->session->userdata('branch_id') != $branch_id)) {
        $this->session->set_flashdata('warning', lang('access_denied'));
        admin_redirect('organization/' . $this->session->userdata('branch_id'));
    } else if ($branch_id == NULL && !($this->Owner || $this->Admin)) {
        admin_redirect('organization/' . $this->session->userdata('branch_id'));
    }

    $this->data['error'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('error');

    if ($this->Owner || $this->Admin || !$this->session->userdata('branch_id')) {
        $this->data['branches'] = $this->site->getAllBranches();
        $this->data['branch_id'] = $branch_id;
        $this->data['branch'] = $branch_id ? $this->site->getBranchByID($branch_id) : NULL;
    } else {
        $this->data['branches'] = NULL;
        $this->data['branch_id'] = $this->session->userdata('branch_id');
        $this->data['branch'] = $this->session->userdata('branch_id') ? $this->site->getBranchByID($this->session->userdata('branch_id')) : NULL;
    }






    


    if ($branch_id) {


        $this->data['thana_info'] = $this->site->query("SELECT sma_district.name thana_name ,v3_district_upazila( sma_district.parent_top_level) district_name, b.*  FROM `sma_district` LEFT JOIN  
		
		(  SELECT          org_thana,
                    org_ward,
                    org_unit,
                    branch_number,
                    supporter_organization,district,upazila,
                     v3_count_zone(upazila, 1, 3,2) paurosova_number,
                      v3_count_zone(upazila, 2, 3,2) union_number
                    FROM (
                    
                    SELECT 
                    SUM(CASE WHEN sma_thana.`level` = 1 THEN 1 ELSE 0 END) org_thana,
                    SUM(CASE WHEN sma_thana.`level` = 2 THEN 1 ELSE 0 END) org_ward,
                    SUM(CASE WHEN sma_thana.`level` = 3 THEN 1 ELSE 0 END) org_unit,
                    SUM(supporter_organization) supporter_organization,
                    COUNT(DISTINCT(branch_id)) branch_number, 
                    district, upazila 
                    FROM sma_thana 
                    LEFT JOIN sma_district ON sma_district.id = sma_thana.upazila 
                                       
                    
                    WHERE 
                     branch_id = $branch_id AND   sma_district.level = 2 AND   sma_district.zone_type =2             
                     GROUP BY  district,upazila 
                        
                    ) a 
                    
                                        
                    )b ON sma_district.id = b.upazila WHERE sma_district.level=2 AND sma_district.zone_type = 2
                    AND   sma_district.id  IN (
SELECT DISTINCT thana_upazila_id FROM   sma_administrative_area WHERE   branch_id = $branch_id                   
                    )
                    ");



    } else {

        $this->data['district_info'] = $this->site->query("SELECT sma_district.name thana_name ,v3_district_upazila( sma_district.parent_top_level) district_name, b.*  FROM `sma_district` LEFT JOIN  
		
		(  SELECT          org_thana,
                    org_ward,
                    org_unit,
                    branch_number,
                    supporter_organization,district,upazila,
                      v3_count_zone(upazila, 1, 3,2) paurosova_number,
                      v3_count_zone(upazila, 2, 3,2) union_number
                    FROM (
                    
                    SELECT 
                    SUM(CASE WHEN sma_thana.`level` = 1 THEN 1 ELSE 0 END) org_thana,
                    SUM(CASE WHEN sma_thana.`level` = 2 THEN 1 ELSE 0 END) org_ward,
                    SUM(CASE WHEN sma_thana.`level` = 3 THEN 1 ELSE 0 END) org_unit,
                    SUM(supporter_organization) supporter_organization,
                    COUNT(DISTINCT(branch_id)) branch_number, 
                    district, upazila 
                    FROM sma_thana 
                    LEFT JOIN sma_district ON sma_district.id = sma_thana.upazila 
                                       
                    
                    WHERE 
                        sma_district.level = 2 AND   sma_district.zone_type = 2              
                     GROUP BY  district,upazila 
                        
                    ) a 
                    
                                        
                    )b ON sma_district.id = b.upazila WHERE sma_district.level=2 AND sma_district.zone_type = 2");
    }




   


    /// $this->sma->print_arrays($this->data['org_summary']);
    $bc = array(array('link' => base_url(), 'page' => lang('home')), array('link' => '#', 'page' => 'Administrative detail'));
    $meta = array('page_title' => 'Administrative detail', 'bc' => $bc);
   
        $this->page_construct('administrativedetail/upazila', $meta, $this->data, 'leftmenu/organization');


}






function pourosova( $branch_id = NULL)
{


   
    $this->sma->checkPermissions();
    if ($branch_id != NULL && !($this->Owner || $this->Admin) && ($this->session->userdata('branch_id') != $branch_id)) {
        $this->session->set_flashdata('warning', lang('access_denied'));
        admin_redirect('organization/' . $this->session->userdata('branch_id'));
    } else if ($branch_id == NULL && !($this->Owner || $this->Admin)) {
        admin_redirect('organization/' . $this->session->userdata('branch_id'));
    }

    $this->data['error'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('error');

    if ($this->Owner || $this->Admin || !$this->session->userdata('branch_id')) {
        $this->data['branches'] = $this->site->getAllBranches();
        $this->data['branch_id'] = $branch_id;
        $this->data['branch'] = $branch_id ? $this->site->getBranchByID($branch_id) : NULL;
    } else {
        $this->data['branches'] = NULL;
        $this->data['branch_id'] = $this->session->userdata('branch_id');
        $this->data['branch'] = $this->session->userdata('branch_id') ? $this->site->getBranchByID($this->session->userdata('branch_id')) : NULL;
    }






    


    if ($branch_id) {


        $this->data['thana_info'] = $this->site->query("SELECT sma_district.name pourosova_name ,v3_district_upazila( sma_district.parent_top_level) district_name,
v3_district_upazila( sma_district.parent_second_level) upazila_name,
 b.ward_number,b.org_thana,b.org_ward,b.org_unit, b.supporter_organization, b.branch_number  FROM `sma_district` LEFT JOIN  
		
		(  
		
		    SELECT       org_thana,
                    org_ward,
                    org_unit,
                    branch_number,
                    supporter_organization,district,upazila,`union` pourosova, 
                  --  `v3_count_zone`(in_parent_id  INT, in_zone_type  INT, in_zone_level  INT, in_parent_level INT)
                    v3_count_zone(`union`, 1, 4,3) ward_number
                    FROM (
                    
                    SELECT 
                    SUM(CASE WHEN sma_thana.`level` = 1 THEN 1 ELSE 0 END) org_thana,
                    SUM(CASE WHEN sma_thana.`level` = 2 THEN 1 ELSE 0 END) org_ward,
                    SUM(CASE WHEN sma_thana.`level` = 3 THEN 1 ELSE 0 END) org_unit,
                    SUM(supporter_organization) supporter_organization,
                    COUNT(DISTINCT(branch_id)) branch_number, 
                    district, upazila, `union`
                    FROM sma_thana 
                    LEFT JOIN sma_district ON sma_district.id = sma_thana.`union`
                                       
                    
                    WHERE 
                      branch_id = $branch_id AND  sma_district.level = 3 AND   sma_district.zone_type = 1             
                     GROUP BY  district,upazila ,`union`
                        
                    ) a 
                    
                                        
                    )b ON sma_district.id = b.pourosova WHERE sma_district.level=3 AND sma_district.zone_type = 1");



    } else {

        $this->data['district_info'] = $this->site->query("SELECT sma_district.name pourosova_name ,v3_district_upazila( sma_district.parent_top_level) district_name,
v3_district_upazila( sma_district.parent_second_level) upazila_name,
 b.ward_number,b.org_thana,b.org_ward,b.org_unit, b.supporter_organization, b.branch_number  FROM `sma_district` LEFT JOIN  
		
		(  
		
		    SELECT       org_thana,
                    org_ward,
                    org_unit,
                    branch_number,
                    supporter_organization,district,upazila,`union` pourosova, 
                  --  `v3_count_zone`(in_parent_id  INT, in_zone_type  INT, in_zone_level  INT, in_parent_level INT)
                    v3_count_zone(`union`, 1, 4,3) ward_number
                    FROM (
                    
                    SELECT 
                    SUM(CASE WHEN sma_thana.`level` = 1 THEN 1 ELSE 0 END) org_thana,
                    SUM(CASE WHEN sma_thana.`level` = 2 THEN 1 ELSE 0 END) org_ward,
                    SUM(CASE WHEN sma_thana.`level` = 3 THEN 1 ELSE 0 END) org_unit,
                    SUM(supporter_organization) supporter_organization,
                    COUNT(DISTINCT(branch_id)) branch_number, 
                    district, upazila, `union`
                    FROM sma_thana 
                    LEFT JOIN sma_district ON sma_district.id = sma_thana.`union`
                                       
                    
                    WHERE 
                       sma_district.level = 3 AND   sma_district.zone_type = 1             
                     GROUP BY  district,upazila ,`union`
                        
                    ) a 
                    
                                        
                    )b ON sma_district.id = b.pourosova WHERE sma_district.level=3 AND sma_district.zone_type = 1");
    }




   


    /// $this->sma->print_arrays($this->data['org_summary']);
    $bc = array(array('link' => base_url(), 'page' => lang('home')), array('link' => '#', 'page' => 'Administrative detail'));
    $meta = array('page_title' => 'Administrative detail', 'bc' => $bc);
   
        $this->page_construct('administrativedetail/pourosova', $meta, $this->data, 'leftmenu/organization');


}







function union( $branch_id = NULL)
{


   
    $this->sma->checkPermissions();
    if ($branch_id != NULL && !($this->Owner || $this->Admin) && ($this->session->userdata('branch_id') != $branch_id)) {
        $this->session->set_flashdata('warning', lang('access_denied'));
        admin_redirect('organization/' . $this->session->userdata('branch_id'));
    } else if ($branch_id == NULL && !($this->Owner || $this->Admin)) {
        admin_redirect('organization/' . $this->session->userdata('branch_id'));
    }

    $this->data['error'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('error');

    if ($this->Owner || $this->Admin || !$this->session->userdata('branch_id')) {
        $this->data['branches'] = $this->site->getAllBranches();
        $this->data['branch_id'] = $branch_id;
        $this->data['branch'] = $branch_id ? $this->site->getBranchByID($branch_id) : NULL;
    } else {
        $this->data['branches'] = NULL;
        $this->data['branch_id'] = $this->session->userdata('branch_id');
        $this->data['branch'] = $this->session->userdata('branch_id') ? $this->site->getBranchByID($this->session->userdata('branch_id')) : NULL;
    }






    


    if ($branch_id) {


        $this->data['thana_info'] = $this->site->query("SELECT sma_district.name union_name ,v3_district_upazila( sma_district.parent_top_level) district_name,
v3_district_upazila( sma_district.parent_second_level) upazila_name,
 b.ward_number,b.org_thana,b.org_ward,b.org_unit, b.supporter_organization, b.branch_number  FROM `sma_district` LEFT JOIN  
		
		(  
		
		    SELECT       org_thana,
                    org_ward,
                    org_unit,
                    branch_number,
                    supporter_organization,district,upazila,`union`, 
                  --  `v3_count_zone`(in_parent_id  INT, in_zone_type  INT, in_zone_level  INT, in_parent_level INT)
                    v3_count_zone(`union`, 1, 4,3) ward_number
                    FROM (
                    
                    SELECT 
                    SUM(CASE WHEN sma_thana.`level` = 1 THEN 1 ELSE 0 END) org_thana,
                    SUM(CASE WHEN sma_thana.`level` = 2 THEN 1 ELSE 0 END) org_ward,
                    SUM(CASE WHEN sma_thana.`level` = 3 THEN 1 ELSE 0 END) org_unit,
                    SUM(supporter_organization) supporter_organization,
                    COUNT(DISTINCT(branch_id)) branch_number, 
                    district, upazila, `union`
                    FROM sma_thana 
                    LEFT JOIN sma_district ON sma_district.id = sma_thana.`union`
                                       
                    
                    WHERE 
                      branch_id = $branch_id AND  sma_district.level = 3 AND   sma_district.zone_type = 2             
                     GROUP BY  district,upazila ,`union`
                        
                    ) a 
                    
                                        
                    )b ON sma_district.id = b.union WHERE sma_district.level=3 AND sma_district.zone_type = 2");



    } else {

        $this->data['district_info'] = $this->site->query("SELECT sma_district.name union_name ,v3_district_upazila( sma_district.parent_top_level) district_name,
v3_district_upazila( sma_district.parent_second_level) upazila_name,
 b.ward_number,b.org_thana,b.org_ward,b.org_unit, b.supporter_organization, b.branch_number  FROM `sma_district` LEFT JOIN  
		
		(  
		
		    SELECT       org_thana,
                    org_ward,
                    org_unit,
                    branch_number,
                    supporter_organization,district,upazila,`union`, 
                  --  `v3_count_zone`(in_parent_id  INT, in_zone_type  INT, in_zone_level  INT, in_parent_level INT)
                    v3_count_zone(`union`, 1, 4,3) ward_number
                    FROM (
                    
                    SELECT 
                    SUM(CASE WHEN sma_thana.`level` = 1 THEN 1 ELSE 0 END) org_thana,
                    SUM(CASE WHEN sma_thana.`level` = 2 THEN 1 ELSE 0 END) org_ward,
                    SUM(CASE WHEN sma_thana.`level` = 3 THEN 1 ELSE 0 END) org_unit,
                    SUM(supporter_organization) supporter_organization,
                    COUNT(DISTINCT(branch_id)) branch_number, 
                    district, upazila, `union`
                    FROM sma_thana 
                    LEFT JOIN sma_district ON sma_district.id = sma_thana.`union`
                                       
                    
                    WHERE 
                        sma_district.level = 3 AND   sma_district.zone_type = 2             
                     GROUP BY  district,upazila ,`union`
                        
                    ) a 
                    
                                        
                    )b ON sma_district.id = b.union WHERE sma_district.level=3 AND sma_district.zone_type = 2");
    }




   


    /// $this->sma->print_arrays($this->data['org_summary']);
    $bc = array(array('link' => base_url(), 'page' => lang('home')), array('link' => '#', 'page' => 'Administrative detail'));
    $meta = array('page_title' => 'Administrative detail', 'bc' => $bc);
   
        $this->page_construct('administrativedetail/union', $meta, $this->data, 'leftmenu/organization');


}



function cityward( $branch_id = NULL)
{


   
    $this->sma->checkPermissions();
    if ($branch_id != NULL && !($this->Owner || $this->Admin) && ($this->session->userdata('branch_id') != $branch_id)) {
        $this->session->set_flashdata('warning', lang('access_denied'));
        admin_redirect('organization/' . $this->session->userdata('branch_id'));
    } else if ($branch_id == NULL && !($this->Owner || $this->Admin)) {
        admin_redirect('organization/' . $this->session->userdata('branch_id'));
    }

    $this->data['error'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('error');

    if ($this->Owner || $this->Admin || !$this->session->userdata('branch_id')) {
        $this->data['branches'] = $this->site->getAllBranches();
        $this->data['branch_id'] = $branch_id;
        $this->data['branch'] = $branch_id ? $this->site->getBranchByID($branch_id) : NULL;
    } else {
        $this->data['branches'] = NULL;
        $this->data['branch_id'] = $this->session->userdata('branch_id');
        $this->data['branch'] = $this->session->userdata('branch_id') ? $this->site->getBranchByID($this->session->userdata('branch_id')) : NULL;
    }






    


    if ($branch_id) {


        $this->data['thana_info'] = $this->site->query("SELECT sma_district.name ward_name, v3_district_upazila( sma_district.parent_top_level) district_name,
v3_district_upazila( sma_district.parent_second_level) thana_name, v3_district_upazila( sma_district.parent_third_level) union_name,
  b.org_thana,b.org_ward,b.org_unit, b.supporter_organization, b.branch_number  FROM `sma_district` LEFT JOIN  
		
		(  
		
		    SELECT       org_thana,
                    org_ward,
                    org_unit,
                    branch_number,
                    supporter_organization,district,upazila,`union`, ward
                  --  `v3_count_zone`(in_parent_id  INT, in_zone_type  INT, in_zone_level  INT, in_parent_level INT)
                  --  v3_count_zone(`union`, 1, 4,3) ward_number
                    FROM (
                    
                    SELECT 
                    SUM(CASE WHEN sma_thana.`level` = 1 THEN 1 ELSE 0 END) org_thana,
                    SUM(CASE WHEN sma_thana.`level` = 2 THEN 1 ELSE 0 END) org_ward,
                    SUM(CASE WHEN sma_thana.`level` = 3 THEN 1 ELSE 0 END) org_unit,
                    SUM(supporter_organization) supporter_organization,
                    COUNT(DISTINCT(branch_id)) branch_number, 
                    district, upazila, `union`, ward
                    FROM sma_thana 
                    LEFT JOIN sma_district ON sma_district.id = sma_thana.`ward`
                                       
                    
                    WHERE 
                      branch_id = $branch_id AND  sma_district.level = 4 AND   sma_district.zone_type = 1             
                     GROUP BY  district,upazila ,`union`, ward
                        
                    ) a 
                    
                                        
                    )b ON sma_district.id = b.ward WHERE sma_district.level = 4 AND sma_district.zone_type = 1");



    } else {

        $this->data['district_info'] = $this->site->query("SELECT sma_district.name ward_name, v3_district_upazila( sma_district.parent_top_level) district_name,
v3_district_upazila( sma_district.parent_second_level) thana_name, v3_district_upazila( sma_district.parent_third_level) union_name,
  b.org_thana,b.org_ward,b.org_unit, b.supporter_organization, b.branch_number  FROM `sma_district` LEFT JOIN  
		
		(  
		
		    SELECT       org_thana,
                    org_ward,
                    org_unit,
                    branch_number,
                    supporter_organization,district,upazila,`union`, ward
                  --  `v3_count_zone`(in_parent_id  INT, in_zone_type  INT, in_zone_level  INT, in_parent_level INT)
                  --  v3_count_zone(`union`, 1, 4,3) ward_number
                    FROM (
                    
                    SELECT 
                    SUM(CASE WHEN sma_thana.`level` = 1 THEN 1 ELSE 0 END) org_thana,
                    SUM(CASE WHEN sma_thana.`level` = 2 THEN 1 ELSE 0 END) org_ward,
                    SUM(CASE WHEN sma_thana.`level` = 3 THEN 1 ELSE 0 END) org_unit,
                    SUM(supporter_organization) supporter_organization,
                    COUNT(DISTINCT(branch_id)) branch_number, 
                    district, upazila, `union`, ward
                    FROM sma_thana 
                    LEFT JOIN sma_district ON sma_district.id = sma_thana.`ward`
                                       
                    
                    WHERE 
                        sma_district.level = 4 AND   sma_district.zone_type = 1             
                     GROUP BY  district,upazila ,`union`, ward
                        
                    ) a 
                    
                                        
                    )b ON sma_district.id = b.ward WHERE sma_district.level = 4 AND sma_district.zone_type = 1");
    }




   


    /// $this->sma->print_arrays($this->data['org_summary']);
    $bc = array(array('link' => base_url(), 'page' => lang('home')), array('link' => '#', 'page' => 'Administrative detail'));
    $meta = array('page_title' => 'Administrative detail', 'bc' => $bc);
   
        $this->page_construct('administrativedetail/cityward', $meta, $this->data, 'leftmenu/organization');


}




function pouroward( $branch_id = NULL)
{


   
    $this->sma->checkPermissions();
    if ($branch_id != NULL && !($this->Owner || $this->Admin) && ($this->session->userdata('branch_id') != $branch_id)) {
        $this->session->set_flashdata('warning', lang('access_denied'));
        admin_redirect('organization/' . $this->session->userdata('branch_id'));
    } else if ($branch_id == NULL && !($this->Owner || $this->Admin)) {
        admin_redirect('organization/' . $this->session->userdata('branch_id'));
    }

    $this->data['error'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('error');

    if ($this->Owner || $this->Admin || !$this->session->userdata('branch_id')) {
        $this->data['branches'] = $this->site->getAllBranches();
        $this->data['branch_id'] = $branch_id;
        $this->data['branch'] = $branch_id ? $this->site->getBranchByID($branch_id) : NULL;
    } else {
        $this->data['branches'] = NULL;
        $this->data['branch_id'] = $this->session->userdata('branch_id');
        $this->data['branch'] = $this->session->userdata('branch_id') ? $this->site->getBranchByID($this->session->userdata('branch_id')) : NULL;
    }






    


    if ($branch_id) {


        $this->data['thana_info'] = $this->site->query("SELECT sma_district.name ward_name, v3_district_upazila( sma_district.parent_top_level) district_name,
v3_district_upazila( sma_district.parent_second_level) thana_name, v3_district_upazila( sma_district.parent_third_level) pourosova_name,
  b.org_thana,b.org_ward,b.org_unit, b.supporter_organization, b.branch_number  FROM `sma_district` LEFT JOIN  
		
		(  
		
		    SELECT       org_thana,
                    org_ward,
                    org_unit,
                    branch_number,
                    supporter_organization,district,upazila,`union` pourosova, ward
                  --  `v3_count_zone`(in_parent_id  INT, in_zone_type  INT, in_zone_level  INT, in_parent_level INT)
                  --  v3_count_zone(`union`, 1, 4,3) ward_number
                    FROM (
                    
                    SELECT 
                    SUM(CASE WHEN sma_thana.`level` = 1 THEN 1 ELSE 0 END) org_thana,
                    SUM(CASE WHEN sma_thana.`level` = 2 THEN 1 ELSE 0 END) org_ward,
                    SUM(CASE WHEN sma_thana.`level` = 3 THEN 1 ELSE 0 END) org_unit,
                    SUM(supporter_organization) supporter_organization,
                    COUNT(DISTINCT(branch_id)) branch_number, 
                    district, upazila, `union`, ward
                    FROM sma_thana 
                    LEFT JOIN sma_district ON sma_district.id = sma_thana.`ward`
                                       
                    
                    WHERE 
                        branch_id = $branch_id AND sma_district.level = 4 AND   sma_district.zone_type = 3             
                     GROUP BY  district,upazila ,`union`, ward
                        
                    ) a 
                    
                                        
                    )b ON sma_district.id = b.ward WHERE sma_district.level = 4 AND sma_district.zone_type = 3");



    } else {

        $this->data['district_info'] = $this->site->query("SELECT sma_district.name ward_name, v3_district_upazila( sma_district.parent_top_level) district_name,
v3_district_upazila( sma_district.parent_second_level) thana_name, v3_district_upazila( sma_district.parent_third_level) pourosova_name,
  b.org_thana,b.org_ward,b.org_unit, b.supporter_organization, b.branch_number  FROM `sma_district` LEFT JOIN  
		
		(  
		
		    SELECT       org_thana,
                    org_ward,
                    org_unit,
                    branch_number,
                    supporter_organization,district,upazila,`union` pourosova, ward
                  --  `v3_count_zone`(in_parent_id  INT, in_zone_type  INT, in_zone_level  INT, in_parent_level INT)
                  --  v3_count_zone(`union`, 1, 4,3) ward_number
                    FROM (
                    
                    SELECT 
                    SUM(CASE WHEN sma_thana.`level` = 1 THEN 1 ELSE 0 END) org_thana,
                    SUM(CASE WHEN sma_thana.`level` = 2 THEN 1 ELSE 0 END) org_ward,
                    SUM(CASE WHEN sma_thana.`level` = 3 THEN 1 ELSE 0 END) org_unit,
                    SUM(supporter_organization) supporter_organization,
                    COUNT(DISTINCT(branch_id)) branch_number, 
                    district, upazila, `union`, ward
                    FROM sma_thana 
                    LEFT JOIN sma_district ON sma_district.id = sma_thana.`ward`
                                       
                    
                    WHERE 
                        sma_district.level = 4 AND   sma_district.zone_type = 3             
                     GROUP BY  district,upazila ,`union`, ward
                        
                    ) a 
                    
                                        
                    )b ON sma_district.id = b.ward WHERE sma_district.level = 4 AND sma_district.zone_type = 3");
    }




   


    /// $this->sma->print_arrays($this->data['org_summary']);
    $bc = array(array('link' => base_url(), 'page' => lang('home')), array('link' => '#', 'page' => 'Administrative detail'));
    $meta = array('page_title' => 'Administrative detail', 'bc' => $bc);
   
        $this->page_construct('administrativedetail/pouroward', $meta, $this->data, 'leftmenu/organization');


}



function unionward( $branch_id = NULL)
{


   
    $this->sma->checkPermissions();
    if ($branch_id != NULL && !($this->Owner || $this->Admin) && ($this->session->userdata('branch_id') != $branch_id)) {
        $this->session->set_flashdata('warning', lang('access_denied'));
        admin_redirect('organization/' . $this->session->userdata('branch_id'));
    } else if ($branch_id == NULL && !($this->Owner || $this->Admin)) {
        admin_redirect('organization/' . $this->session->userdata('branch_id'));
    }

    $this->data['error'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('error');

    if ($this->Owner || $this->Admin || !$this->session->userdata('branch_id')) {
        $this->data['branches'] = $this->site->getAllBranches();
        $this->data['branch_id'] = $branch_id;
        $this->data['branch'] = $branch_id ? $this->site->getBranchByID($branch_id) : NULL;
    } else {
        $this->data['branches'] = NULL;
        $this->data['branch_id'] = $this->session->userdata('branch_id');
        $this->data['branch'] = $this->session->userdata('branch_id') ? $this->site->getBranchByID($this->session->userdata('branch_id')) : NULL;
    }






    


    if ($branch_id) {


        $this->data['thana_info'] = $this->site->query("SELECT sma_district.name ward_name, v3_district_upazila( sma_district.parent_top_level) district_name,
v3_district_upazila( sma_district.parent_second_level) thana_name, v3_district_upazila( sma_district.parent_third_level) union_name,
  b.org_thana,b.org_ward,b.org_unit, b.supporter_organization, b.branch_number  FROM `sma_district` LEFT JOIN  
		
		(  
		
		    SELECT       org_thana,
                    org_ward,
                    org_unit,
                    branch_number,
                    supporter_organization,district,upazila,`union`, ward
                  --  `v3_count_zone`(in_parent_id  INT, in_zone_type  INT, in_zone_level  INT, in_parent_level INT)
                  --  v3_count_zone(`union`, 1, 4,3) ward_number
                    FROM (
                    
                    SELECT 
                    SUM(CASE WHEN sma_thana.`level` = 1 THEN 1 ELSE 0 END) org_thana,
                    SUM(CASE WHEN sma_thana.`level` = 2 THEN 1 ELSE 0 END) org_ward,
                    SUM(CASE WHEN sma_thana.`level` = 3 THEN 1 ELSE 0 END) org_unit,
                    SUM(supporter_organization) supporter_organization,
                    COUNT(DISTINCT(branch_id)) branch_number, 
                    district, upazila, `union`, ward
                    FROM sma_thana 
                    LEFT JOIN sma_district ON sma_district.id = sma_thana.`ward`
                                       
                    
                    WHERE 
                      branch_id = $branch_id AND  sma_district.level = 4 AND   sma_district.zone_type = 2             
                     GROUP BY  district,upazila ,`union`, ward
                        
                    ) a 
                    
                                        
                    )b ON sma_district.id = b.ward WHERE sma_district.level = 4 AND sma_district.zone_type = 2");



    } else {

        $this->data['district_info'] = $this->site->query("SELECT sma_district.name ward_name, v3_district_upazila( sma_district.parent_top_level) district_name,
v3_district_upazila( sma_district.parent_second_level) thana_name, v3_district_upazila( sma_district.parent_third_level) union_name,
  b.org_thana,b.org_ward,b.org_unit, b.supporter_organization, b.branch_number  FROM `sma_district` LEFT JOIN  
		
		(  
		
		    SELECT       org_thana,
                    org_ward,
                    org_unit,
                    branch_number,
                    supporter_organization,district,upazila,`union`, ward
                  --  `v3_count_zone`(in_parent_id  INT, in_zone_type  INT, in_zone_level  INT, in_parent_level INT)
                  --  v3_count_zone(`union`, 1, 4,3) ward_number
                    FROM (
                    
                    SELECT 
                    SUM(CASE WHEN sma_thana.`level` = 1 THEN 1 ELSE 0 END) org_thana,
                    SUM(CASE WHEN sma_thana.`level` = 2 THEN 1 ELSE 0 END) org_ward,
                    SUM(CASE WHEN sma_thana.`level` = 3 THEN 1 ELSE 0 END) org_unit,
                    SUM(supporter_organization) supporter_organization,
                    COUNT(DISTINCT(branch_id)) branch_number, 
                    district, upazila, `union`, ward
                    FROM sma_thana 
                    LEFT JOIN sma_district ON sma_district.id = sma_thana.`ward`
                                       
                    
                    WHERE 
                        sma_district.level = 4 AND   sma_district.zone_type = 2             
                     GROUP BY  district,upazila ,`union`, ward
                        
                    ) a 
                    
                                        
                    )b ON sma_district.id = b.ward WHERE sma_district.level = 4 AND sma_district.zone_type = 2");
    }




   


    /// $this->sma->print_arrays($this->data['org_summary']);
    $bc = array(array('link' => base_url(), 'page' => lang('home')), array('link' => '#', 'page' => 'Administrative detail'));
    $meta = array('page_title' => 'Administrative detail', 'bc' => $bc);
   
        $this->page_construct('administrativedetail/unionward', $meta, $this->data, 'leftmenu/organization');


}



}
